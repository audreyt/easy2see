(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toESMCache_node;
  var __toESMCache_esm;
  var __toESM = (mod, isNodeMode, target) => {
    var canCache = mod != null && typeof mod === "object";
    if (canCache) {
      var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
      var cached = cache.get(mod);
      if (cached)
        return cached;
    }
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    if (mod && typeof mod === "object" || typeof mod === "function") {
      for (let key of __getOwnPropNames(mod))
        if (!__hasOwnProp.call(to, key))
          __defProp(to, key, {
            get: __accessProp.bind(mod, key),
            enumerable: true
          });
    }
    if (canCache)
      cache.set(mod, to);
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS(function(exports, module) {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });
  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../../mobile/modules/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../../mobile/modules/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../../mobile/modules/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType) {
    MiniappRequestType["CONNECT"] = "miniapp_connect";
    MiniappRequestType["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType["DISPLAY"] = "miniapp_display";
    MiniappRequestType["RENDER"] = "miniapp_render";
    MiniappRequestType["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType["SPEAK"] = "miniapp_speak";
    MiniappRequestType["SPEAKER_STREAM_OPEN"] = "miniapp_speaker_stream_open";
    MiniappRequestType["SPEAKER_STREAM_WRITE"] = "miniapp_speaker_stream_write";
    MiniappRequestType["SPEAKER_STREAM_CLOSE"] = "miniapp_speaker_stream_close";
    MiniappRequestType["SPEAKER_STREAM_ABORT"] = "miniapp_speaker_stream_abort";
    MiniappRequestType["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType["CALENDAR_LIST_EVENTS"] = "miniapp_calendar_list_events";
    MiniappRequestType["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType["CAMERA_WARM_UP"] = "miniapp_camera_warm_up";
    MiniappRequestType["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType["MIC_SET_VAD_ENABLED"] = "miniapp_mic_set_vad_enabled";
    MiniappRequestType["MIC_SET_LOUDNESS_GATE_ENABLED"] = "miniapp_mic_set_loudness_gate_enabled";
    MiniappRequestType["MIC_ACQUIRE"] = "miniapp_mic_acquire";
    MiniappRequestType["MIC_RELEASE"] = "miniapp_mic_release";
    MiniappRequestType["SET_WIFI_ADB_STATE"] = "miniapp_set_wifi_adb_state";
    MiniappRequestType["SHARE"] = "miniapp_share";
    MiniappRequestType["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType["SCAN_QR"] = "miniapp_scan_qr";
    MiniappRequestType["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType["BLOB_EXPORT"] = "miniapp_blob_export";
    MiniappRequestType["PING"] = "miniapp_ping";
    MiniappRequestType["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType["PHOTO"] = "miniapp_photo";
    MiniappRequestType["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType["ACTION_RESULT"] = "miniapp_action_result";
    MiniappRequestType["MEETING_JOIN"] = "miniapp_meeting_join";
    MiniappRequestType["MEETING_LEAVE"] = "miniapp_meeting_leave";
    MiniappRequestType["MEETING_END"] = "miniapp_meeting_end";
    MiniappRequestType["MEETING_ADMIT"] = "miniapp_meeting_admit";
    MiniappRequestType["MEETING_SET_MUTED"] = "miniapp_meeting_set_muted";
    MiniappRequestType["MEETING_UPDATE_VIDEO_SOURCE"] = "miniapp_meeting_update_video_source";
    MiniappRequestType["MEETING_GET_STATE"] = "miniapp_meeting_get_state";
    MiniappRequestType["LLM_AVAILABILITY"] = "miniapp_llm_availability";
    MiniappRequestType["LLM_GENERATE"] = "miniapp_llm_generate";
    MiniappRequestType["LLM_CANCEL"] = "miniapp_llm_cancel";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType) {
    MiniappResponseType["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType["EVENT"] = "miniapp_event";
    MiniappResponseType["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType["PONG"] = "miniapp_pong";
    MiniappResponseType["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType["MEETING_STATE"] = "miniapp_meeting_state";
    MiniappResponseType["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType) {
    MiniappStreamType["BUTTON_PRESS"] = "button_press";
    MiniappStreamType["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType["HEAD_POSITION"] = "head_position";
    MiniappStreamType["ACCEL_DATA"] = "accel_data";
    MiniappStreamType["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType["TRANSCRIPTION"] = "transcription";
    MiniappStreamType["TRANSLATION"] = "translation";
    MiniappStreamType["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType["VAD"] = "vad";
    MiniappStreamType["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode) {
    MiniappErrorCode["INVALID_ARGUMENT"] = "INVALID_ARGUMENT";
    MiniappErrorCode["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode["PERMISSION_DENIED"] = "PERMISSION_DENIED";
    MiniappErrorCode["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode["INTERNAL"] = "INTERNAL";
    MiniappErrorCode["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode["TTS_LOCAL_UNAVAILABLE"] = "TTS_LOCAL_UNAVAILABLE";
    MiniappErrorCode["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode["MIC_SESSION_REQUIRED"] = "MIC_SESSION_REQUIRED";
    MiniappErrorCode["MIC_SOURCE_CONFLICT"] = "MIC_SOURCE_CONFLICT";
    MiniappErrorCode["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
    MiniappErrorCode["LLM_UNAVAILABLE"] = "LLM_UNAVAILABLE";
    MiniappErrorCode["LLM_GUARDRAIL"] = "LLM_GUARDRAIL";
    MiniappErrorCode["LLM_CONTEXT_EXCEEDED"] = "LLM_CONTEXT_EXCEEDED";
    MiniappErrorCode["LLM_CANCELLED"] = "LLM_CANCELLED";
    MiniappErrorCode["LLM_UNSUPPORTED_LANGUAGE"] = "LLM_UNSUPPORTED_LANGUAGE";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../../mobile/modules/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
      this.configuration = { ...options.configuration ?? {} };
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        configuration: { ...this.configuration },
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.CALENDAR_LIST_EVENTS:
        return { events: [], truncated: false };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
      case MiniappRequestType.SET_WIFI_ADB_STATE:
        return { ok: true };
      case MiniappRequestType.SCAN_QR:
        return { cancelled: true };
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../../cloud-v2/packages/protocol/src/photo-compression.ts
  var photoCompressionValues = ["none", "low", "medium", "high"];
  function parsePhotoCompression(value = "none") {
    if (typeof value === "string" && photoCompressionValues.includes(value)) {
      return value;
    }
    throw new TypeError(`Invalid photo compression ${JSON.stringify(value)}. Expected none, low, medium, or high.`);
  }

  // ../../mobile/modules/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        ...options.transferMethod !== undefined ? { transferMethod: options.transferMethod } : {},
        compress: parsePhotoCompression(options.compress),
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs,
        iso: options.iso,
        aeExposureDivisor: options.aeExposureDivisor,
        isoCap: options.isoCap,
        noiseReduction: options.noiseReduction,
        edgeEnhancement: options.edgeEnhancement,
        zsl: options.zsl,
        mfnr: options.mfnr,
        ispDigitalGain: options.ispDigitalGain,
        ispAnalogGain: options.ispAnalogGain
      }, options.timeoutMs != null ? { timeoutMs: options.timeoutMs } : undefined);
    }
    async warmUp(options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.CAMERA_WARM_UP,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        exposureTimeNs: options.exposureTimeNs,
        durationMs: options.durationMs ?? 15000,
        zsl: options.zsl,
        mfnr: options.mfnr
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../../mobile/modules/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/configuration.js
  class MiniappConfigurationError extends Error {
    constructor(key) {
      super(`Required miniapp configuration is missing: ${key}`);
      this.key = key;
      this.name = "MiniappConfigurationError";
    }
  }

  class ConfigurationModule {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      await this.session.waitForReady();
      const configuration = this.session._getConfiguration();
      return Object.prototype.hasOwnProperty.call(configuration, key) ? configuration[key] : undefined;
    }
    async require(key) {
      const value = await this.get(key);
      if (value === undefined)
        throw new MiniappConfigurationError(key);
      return value;
    }
    async getAll() {
      await this.session.waitForReady();
      return Object.assign(Object.create(null), this.session._getConfiguration());
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    render(elements, options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RENDER,
        view: options.view ?? "main",
        elements,
        durationMs: options.durationMs
      }).catch((err) => ({
        status: "blocked",
        reason: typeof err === "object" && err !== null && "message" in err ? String(err.message) : String(err)
      }));
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
      this.forceLocalRefCounts = new Map;
      this.engineRefCounts = new Map;
    }
    subscribe(stream, handler, options = {}) {
      const isInternal = stream.startsWith("_");
      const isSpeechStream = stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`) || stream.startsWith(`${MiniappStreamType.TRANSLATION}:`);
      const forceLocal = options.forceLocal === true && isSpeechStream;
      const engine = stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`) && (options.engine === "sherpa" || options.engine === "apple") ? options.engine : "auto";
      const listener = (data, route) => {
        if (isSpeechStream) {
          if (forceLocal ? route !== "forceLocal" && route !== "all" : route === "forceLocal")
            return;
        }
        handler(data);
      };
      this.emitter.on(stream, listener);
      let engineWinnerChanged = false;
      if (forceLocal) {
        const engines = this.engineRefCounts.get(stream) ?? new Map;
        const winnerBefore = (engines.get("apple") ?? 0) > 0 ? "apple" : (engines.get("sherpa") ?? 0) > 0 ? "sherpa" : "auto";
        engines.set(engine, (engines.get(engine) ?? 0) + 1);
        this.engineRefCounts.set(stream, engines);
        const winnerAfter = (engines.get("apple") ?? 0) > 0 ? "apple" : (engines.get("sherpa") ?? 0) > 0 ? "sherpa" : "auto";
        engineWinnerChanged = winnerBefore !== winnerAfter;
      }
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        const forceLocalBefore = this.forceLocalRefCounts.get(stream) ?? 0;
        const defaultBefore = before - forceLocalBefore;
        if (forceLocal)
          this.forceLocalRefCounts.set(stream, forceLocalBefore + 1);
        if (before === 0 || forceLocal && forceLocalBefore === 0 || !forceLocal && defaultBefore === 0 || engineWinnerChanged) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, listener);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        const forceLocalCurrent = this.forceLocalRefCounts.get(stream) ?? 0;
        let subscriptionChanged = current <= 1;
        if (current <= 1) {
          this.refCounts.delete(stream);
        } else {
          this.refCounts.set(stream, current - 1);
        }
        if (forceLocal) {
          if (forceLocalCurrent <= 1) {
            this.forceLocalRefCounts.delete(stream);
            subscriptionChanged = true;
          } else {
            this.forceLocalRefCounts.set(stream, forceLocalCurrent - 1);
          }
          const engines = this.engineRefCounts.get(stream);
          if (engines) {
            const winnerBefore = (engines.get("apple") ?? 0) > 0 ? "apple" : (engines.get("sherpa") ?? 0) > 0 ? "sherpa" : "auto";
            const count = (engines.get(engine) ?? 0) - 1;
            if (count <= 0)
              engines.delete(engine);
            else
              engines.set(engine, count);
            if (engines.size === 0)
              this.engineRefCounts.delete(stream);
            const winnerAfter = (engines.get("apple") ?? 0) > 0 ? "apple" : (engines.get("sherpa") ?? 0) > 0 ? "sherpa" : "auto";
            if (winnerBefore !== winnerAfter)
              subscriptionChanged = true;
          }
        } else if (current - forceLocalCurrent <= 1) {
          subscriptionChanged = true;
        }
        if (subscriptionChanged)
          this.sendSubscriptionUpdate();
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.forceLocalRefCounts.clear();
      this.engineRefCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data, transcriptionRoute) {
      this.emitter.emit(stream, data, transcriptionRoute);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data, transcriptionRoute);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data, transcriptionRoute);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => {
        if (stream === MiniappStreamType.LOCATION_UPDATE)
          return { stream: "location_stream", rate: "realtime" };
        const forceLocalRefs = this.forceLocalRefCounts.get(stream) ?? 0;
        if (forceLocalRefs === 0)
          return stream;
        const totalRefs = this.refCounts.get(stream) ?? 0;
        const engines = this.engineRefCounts.get(stream);
        const engine = (engines?.get("apple") ?? 0) > 0 ? "apple" : (engines?.get("sherpa") ?? 0) > 0 ? "sherpa" : "auto";
        return {
          stream,
          forceLocal: true,
          engine,
          ...totalRefs > forceLocalRefs ? { includeCloud: true } : {}
        };
      });
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
    async setWifiAdbState(enabled) {
      await this.session.sendRequest({
        type: MiniappRequestType.SET_WIFI_ADB_STATE,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    setVoiceActivityDetectionEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_VAD_ENABLED,
        enabled
      });
    }
    setLoudnessGateEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_LOUDNESS_GATE_ENABLED,
        enabled
      });
    }
    async acquire(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MIC_ACQUIRE,
        source: options.source,
        useCase: options.useCase
      });
      if (typeof result?.sessionId !== "number") {
        throw new Error("This version of the Mentra App does not support microphone sessions");
      }
      const { sessionId } = result;
      let released = false;
      return {
        sessionId,
        release: async () => {
          if (released)
            return;
          released = true;
          await this.session.sendRequest({
            type: MiniappRequestType.MIC_RELEASE,
            sessionId
          });
        }
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule {
    constructor(session) {
      this.session = session;
    }
    listEvents(options) {
      const startsAt = normalizeCalendarDate(options?.startsAt, "startsAt");
      const endsAt = normalizeCalendarDate(options?.endsAt, "endsAt");
      return this.session.sendRequest({
        type: MiniappRequestType.CALENDAR_LIST_EVENTS,
        startsAt,
        endsAt,
        ...options.limit === undefined ? {} : { limit: options.limit }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }
  function normalizeCalendarDate(value, field) {
    const date = value instanceof Date ? value : new Date(value ?? "");
    if (Number.isNaN(date.getTime()))
      throw new TypeError(`${field} must be a valid Date or ISO 8601 string`);
    return date.toISOString();
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../../cloud-v2/packages/protocol/src/languages.ts
  var CANONICAL_TAG_BY_CODE = {
    af: "af-ZA",
    am: "am-ET",
    ar: "ar-AE",
    az: "az-AZ",
    be: "be-BY",
    bg: "bg-BG",
    bn: "bn-IN",
    bs: "bs-BA",
    ca: "ca-ES",
    cs: "cs-CZ",
    cy: "cy-GB",
    da: "da-DK",
    de: "de-DE",
    el: "el-GR",
    en: "en-US",
    es: "es-ES",
    et: "et-EE",
    eu: "eu-ES",
    fa: "fa-IR",
    fi: "fi-FI",
    fr: "fr-FR",
    gl: "gl-ES",
    gu: "gu-IN",
    he: "he-IL",
    hi: "hi-IN",
    hr: "hr-HR",
    hu: "hu-HU",
    hy: "hy-AM",
    id: "id-ID",
    it: "it-IT",
    ja: "ja-JP",
    ka: "ka-GE",
    kk: "kk-KZ",
    kn: "kn-IN",
    ko: "ko-KR",
    lt: "lt-LT",
    lv: "lv-LV",
    mk: "mk-MK",
    ml: "ml-IN",
    mr: "mr-IN",
    ms: "ms-MY",
    nb: "nb-NO",
    ne: "ne-NP",
    nl: "nl-NL",
    no: "nb-NO",
    pa: "pa-IN",
    pl: "pl-PL",
    pt: "pt-BR",
    ro: "ro-RO",
    ru: "ru-RU",
    sk: "sk-SK",
    sl: "sl-SI",
    sq: "sq-AL",
    sr: "sr-RS",
    sv: "sv-SE",
    sw: "sw-KE",
    ta: "ta-IN",
    te: "te-IN",
    th: "th-TH",
    tl: "fil-PH",
    tr: "tr-TR",
    uk: "uk-UA",
    ur: "ur-IN",
    vi: "vi-VN",
    zh: "zh-CN"
  };
  var EXTRA_REGIONAL_TAGS = [
    "ar-EG",
    "ar-SA",
    "de-AT",
    "de-CH",
    "en-AU",
    "en-CA",
    "en-GB",
    "en-IN",
    "es-419",
    "es-MX",
    "es-US",
    "fr-CA",
    "nl-BE",
    "pt-PT",
    "zh-HK",
    "zh-TW"
  ];
  var SUPPORTED_LANGUAGE_HINTS = Object.freeze([...new Set(Object.keys(CANONICAL_TAG_BY_CODE))].sort());
  var SUPPORTED_TRANSCRIPTION_LANGUAGES = Object.freeze([
    ...new Set([
      ...Object.values(CANONICAL_TAG_BY_CODE),
      ...EXTRA_REGIONAL_TAGS
    ])
  ].sort());
  var TAG_SET = new Set(SUPPORTED_TRANSCRIPTION_LANGUAGES);
  var HINT_SET = new Set(SUPPORTED_LANGUAGE_HINTS);
  function toTranscriptionLanguage(value) {
    if (TAG_SET.has(value))
      return value;
    const canonical = CANONICAL_TAG_BY_CODE[value.toLowerCase()];
    return canonical ?? null;
  }
  function toLanguageHint(value) {
    const primary = value.split("-")[0].toLowerCase();
    return HINT_SET.has(primary) ? primary : null;
  }
  function suggestTranscriptionLanguage(value) {
    const normalized = value.replace(/_/g, "-");
    const parts = normalized.split("-");
    const recased = parts.length >= 2 ? `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}` : normalized.toLowerCase();
    return toTranscriptionLanguage(recased);
  }

  // ../../mobile/modules/miniapp/dist/modules/languages.js
  class MiniappValidationError extends Error {
    constructor(message) {
      super(message);
      this.name = "MiniappValidationError";
    }
  }
  function requireTranscriptionLanguage(value, param) {
    const canonical = toTranscriptionLanguage(value);
    if (canonical)
      return canonical;
    const suggestion = suggestTranscriptionLanguage(value);
    throw new MiniappValidationError(`${param}: unknown language ${JSON.stringify(value)}` + (suggestion ? ` — did you mean ${JSON.stringify(suggestion)}?` : "") + ` Supported values are BCP-47 tags from SUPPORTED_TRANSCRIPTION_LANGUAGES (e.g. "en-US", "fr-FR").`);
  }
  function requireLanguageHint(value, param) {
    const hint = toLanguageHint(value);
    if (hint)
      return hint;
    throw new MiniappValidationError(`${param}: unknown language hint ${JSON.stringify(value)}. ` + `Hints are bare ISO 639-1 codes from SUPPORTED_LANGUAGE_HINTS (e.g. "en", "fr").`);
  }

  // ../../mobile/modules/miniapp/dist/modules/transcription.js
  var TRANSCRIPTION_ENGINES = { auto: true, sherpa: true, apple: true };
  function requireTranscriptionEngine(engine, param) {
    if (engine === undefined)
      return;
    if (typeof engine !== "string" || TRANSCRIPTION_ENGINES[engine] !== true) {
      throw new MiniappValidationError(`${param}: unknown engine ${JSON.stringify(engine)}. Supported values are "auto", "sherpa", "apple".`);
    }
  }

  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler, options = {}) {
      requireTranscriptionEngine(options.engine, "transcription.on(options.engine)");
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler, options));
    }
    forLanguage(language, handler, options = {}) {
      requireTranscriptionEngine(options.engine, "transcription.forLanguage(options.engine)");
      const langs = (Array.isArray(language) ? language : [language]).map((lang) => requireTranscriptionLanguage(lang, "transcription.forLanguage(language)"));
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler, options));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      const normalized = {
        ...config,
        languageHints: config.languageHints?.map((hint) => requireLanguageHint(hint, "transcription.configure(languageHints)"))
      };
      this.currentConfig = { ...normalized };
      return this.session.sendRequest({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...normalized }
      }).then(() => {
        return;
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler, options = {}) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler, options));
    }
    to(target, handler, options = {}) {
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.to(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler, options));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler, options = {}) {
      const validSource = source === "auto" ? "auto" : requireTranscriptionLanguage(source, "translation.fromTo(source)");
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.fromTo(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${validSource}:${t}`, handler, options));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/speaker.js
  var SPEAKER_WRITE_CHUNK_BYTES = 256 * 1024;
  var SPEAKER_WRITE_CHUNK_B64 = Math.floor(SPEAKER_WRITE_CHUNK_BYTES / 6) * 8;
  class SpeakerStreamWriter {
    constructor(session, streamId) {
      this.session = session;
      this.streamId = streamId;
      this.settled = false;
      this.writeChain = Promise.resolve();
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      if (bytes.byteLength === 0)
        throw new Error("PCM chunk cannot be empty");
      if (bytes.byteLength % 2 !== 0)
        throw new Error("PCM chunk must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < bytes.length; off += SPEAKER_WRITE_CHUNK_BYTES) {
          last = await this.send(bytesToBase64(bytes.subarray(off, off + SPEAKER_WRITE_CHUNK_BYTES)));
        }
        return last;
      });
    }
    async writeBase64(b64) {
      this.assertOpen();
      if (b64.length === 0 || b64.length % 4 !== 0)
        throw new Error("PCM base64 must be non-empty and padded");
      const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
      const decodedBytes = b64.length / 4 * 3 - padding;
      if (decodedBytes % 2 !== 0)
        throw new Error("PCM base64 must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < b64.length; off += SPEAKER_WRITE_CHUNK_B64) {
          last = await this.send(b64.slice(off, off + SPEAKER_WRITE_CHUNK_B64));
        }
        return last;
      });
    }
    async close() {
      this.assertOpen();
      this.settled = true;
      await this.writeChain;
      const res = await this.session.sendRequest({ type: MiniappRequestType.SPEAKER_STREAM_CLOSE, streamId: this.streamId }, { timeoutMs: 0 });
      return res ?? {};
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_ABORT,
        streamId: this.streamId
      });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("SpeakerStreamWriter is already closed/aborted");
    }
    async send(base64) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_WRITE,
        streamId: this.streamId,
        base64
      });
      return res ?? { bufferedMs: 0 };
    }
    enqueueWrite(operation) {
      const result = this.writeChain.then(operation);
      this.writeChain = result.then(() => {
        return;
      }, () => {
        return;
      });
      return result;
    }
  }

  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      const normalized = Array.isArray(text) ? text.map((sentence) => sentence.trim()).filter(Boolean) : text.trim();
      if (Array.isArray(normalized) && normalized.length === 0 || normalized === "") {
        throw { code: MiniappErrorCode.INTERNAL, message: "speak requires at least one non-empty sentence" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text: normalized,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false,
          enableSanitization: options.enableSanitization ?? true,
          forceLocal: options.forceLocal ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    async createStream(options = {}) {
      if (options.volume !== undefined && (!Number.isFinite(options.volume) || options.volume < 0 || options.volume > 1)) {
        throw new RangeError("speaker stream volume must be between 0 and 1");
      }
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_OPEN,
        sampleRate: options.sampleRate ?? 16000,
        channels: options.channels ?? 1,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? true
      });
      return new SpeakerStreamWriter(this.session, res.streamId);
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true,
          ...options.authToken ? { authToken: options.authToken } : {},
          ...typeof options.captureAudio === "boolean" ? { captureAudio: options.captureAudio } : {}
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest,
        ...typeof options.captureAudio === "boolean" ? { captureAudio: options.captureAudio } : {}
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
    async scanQr(options = {}) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SCAN_QR,
        ...options
      }, { timeoutMs: 0 });
      return result ?? { cancelled: true };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr = this.buffered.get(actionId);
        if (arr) {
          const idx = arr.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr.splice(idx, 1);
          if (arr.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta,
        export: opts.export
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
    async exportToFiles(key, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_EXPORT,
        key,
        folder: opts.folder,
        filename: opts.filename,
        keepBlob: opts.keepBlob === true
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/meeting.js
  var MEETING_HOST_UPDATE_MESSAGE = "Update the Mentra App to use Teams calling";
  function validateMeetingVideoSource(source) {
    const value = source ?? {};
    if (value.type === "whep") {
      const url = typeof value.url === "string" ? value.url.trim() : "";
      if (!url) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "videoSource.url is required for a WHEP source" };
      }
      return { type: "whep", url };
    }
    if (value.type === "softap") {
      const ssid = typeof value.ssid === "string" ? value.ssid.trim() : "";
      const passphrase = typeof value.passphrase === "string" ? value.passphrase : "";
      if (Boolean(ssid) !== Boolean(passphrase)) {
        throw {
          code: MiniappErrorCode.INVALID_ARGUMENT,
          message: "videoSource.ssid and videoSource.passphrase must be provided together"
        };
      }
      return ssid ? { type: "softap", ssid, passphrase } : { type: "softap" };
    }
    throw {
      code: MiniappErrorCode.INVALID_ARGUMENT,
      message: `videoSource must be {type: "whep", url} or {type: "softap"}`
    };
  }
  function parseMeetingEndReason(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    const number = (field) => typeof field === "number" && Number.isFinite(field) ? field : undefined;
    const code = number(value.code);
    const subcode = number(value.subcode);
    const message = typeof value.message === "string" && value.message ? value.message : undefined;
    if (code === undefined && subcode === undefined && message === undefined)
      return;
    return {
      ...code !== undefined ? { code } : {},
      ...subcode !== undefined ? { subcode } : {},
      ...message !== undefined ? { message } : {}
    };
  }
  function parseMeetingCapabilities(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw.hangUpForEveryone;
    if (!value || typeof value !== "object")
      return;
    const capability = value;
    const rawLobby = raw.manageLobby;
    const lobby = rawLobby && typeof rawLobby === "object" ? rawLobby : undefined;
    return {
      ...lobby ? { manageLobby: {
        allowed: typeof lobby.allowed === "boolean" ? lobby.allowed : null,
        reason: typeof lobby.reason === "string" && lobby.reason ? lobby.reason : null
      } } : {},
      hangUpForEveryone: {
        allowed: typeof capability.allowed === "boolean" ? capability.allowed : null,
        reason: typeof capability.reason === "string" && capability.reason ? capability.reason : null
      }
    };
  }
  var SOFTAP_STEPS = new Set(["hotspot", "scopedJoin", "acsJoin", "publish", "live"]);
  var SOFTAP_STEP_STATUSES = new Set(["pending", "running", "done", "failed"]);
  var SOFTAP_PHASES = new Set([
    "idle",
    "starting",
    "recovering",
    "live",
    "stopping",
    "failed"
  ]);
  function parseMeetingSoftApProgress(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    if (!SOFTAP_PHASES.has(String(value.phase)) || !Array.isArray(value.steps))
      return;
    const steps = [];
    for (const entry of value.steps) {
      if (!entry || typeof entry !== "object")
        continue;
      const step = entry;
      if (!SOFTAP_STEPS.has(String(step.step)) || !SOFTAP_STEP_STATUSES.has(String(step.status)))
        continue;
      steps.push({
        step: step.step,
        status: step.status,
        detail: typeof step.detail === "string" && step.detail ? step.detail : undefined,
        error: typeof step.error === "string" && step.error ? step.error : undefined,
        durationMs: typeof step.durationMs === "number" && Number.isFinite(step.durationMs) ? step.durationMs : undefined
      });
    }
    return {
      traceId: typeof value.traceId === "string" && value.traceId ? value.traceId : undefined,
      phase: value.phase,
      steps,
      elapsedMs: typeof value.elapsedMs === "number" && Number.isFinite(value.elapsedMs) ? value.elapsedMs : 0
    };
  }
  function parseMeetingRecovery(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    if (typeof value.active !== "boolean")
      return;
    const generation = typeof value.generation === "number" && Number.isFinite(value.generation) ? value.generation : undefined;
    const deadlineAt = typeof value.deadlineAt === "number" && Number.isFinite(value.deadlineAt) ? value.deadlineAt : undefined;
    const phase = typeof value.phase === "string" && value.phase ? value.phase : undefined;
    return {
      active: value.active,
      ...generation !== undefined ? { generation } : {},
      ...deadlineAt !== undefined ? { deadlineAt } : {},
      ...phase ? { phase } : {}
    };
  }
  var PARTICIPANT_STATES = new Set([
    "idle",
    "connecting",
    "connected",
    "lobby",
    "hold",
    "disconnected"
  ]);
  var MEDIA_SOURCES = new Set(["idle", "connecting", "live", "failed"]);
  function parseMeetingMediaSource(raw) {
    return MEDIA_SOURCES.has(String(raw)) ? raw : undefined;
  }
  function parseMeetingParticipants(raw) {
    if (!Array.isArray(raw))
      return;
    const result = [];
    for (const entry of raw) {
      if (!entry || typeof entry !== "object")
        continue;
      const value = entry;
      if (typeof value.id !== "string" || !value.id)
        continue;
      result.push({
        id: value.id,
        displayName: typeof value.displayName === "string" && value.displayName ? value.displayName : null,
        state: PARTICIPANT_STATES.has(String(value.state)) ? value.state : "idle",
        isMuted: Boolean(value.isMuted),
        isSpeaking: Boolean(value.isSpeaking)
      });
    }
    return result;
  }
  function isMiniappRequestError(error) {
    return Boolean(error && typeof error === "object" && "code" in error);
  }
  function mapHostError(error) {
    if (isMiniappRequestError(error) && error.code === MiniappErrorCode.NOT_IMPLEMENTED) {
      throw { code: MiniappErrorCode.NOT_IMPLEMENTED, message: MEETING_HOST_UPDATE_MESSAGE };
    }
    throw error;
  }

  class MeetingModule {
    constructor(session) {
      this.session = session;
      this._state = { state: "idle", muted: false };
    }
    get state() {
      return { ...this._state };
    }
    async join(options) {
      if (options.provider !== "acs-teams") {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: `Unsupported meeting provider: ${options.provider}` };
      }
      if (!options.meetingUrl?.trim()) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "meetingUrl is required" };
      }
      const videoSource = validateMeetingVideoSource(options.videoSource);
      if (!options.token?.trim()) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "token is required" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_JOIN,
          provider: options.provider,
          meetingUrl: options.meetingUrl,
          videoSource,
          token: options.token,
          displayName: options.displayName,
          ...options.origin ? { origin: options.origin } : {},
          ...options.video ? { video: options.video } : {}
        }, { timeoutMs: 0 });
        if (result)
          this._applyState(result);
        return this.state;
      } catch (error) {
        mapHostError(error);
      }
    }
    async leave() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_LEAVE });
      } catch (error) {
        mapHostError(error);
      }
    }
    async end() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_END }, { timeoutMs: 0 });
      } catch (error) {
        mapHostError(error);
      }
    }
    async admit(participantId) {
      if (!participantId.trim())
        throw new Error("A participant ID is required");
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_ADMIT, participantId });
      } catch (error) {
        mapHostError(error);
      }
    }
    async setMuted(muted) {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_SET_MUTED,
          muted
        });
        if (result)
          this._applyState(result);
      } catch (error) {
        mapHostError(error);
      }
    }
    async updateVideoSource(source) {
      const validated = validateMeetingVideoSource(source);
      if (validated.type !== "whep") {
        throw {
          code: MiniappErrorCode.INVALID_ARGUMENT,
          message: "updateVideoSource accepts a WHEP source; a SoftAP call recovers by rejoining"
        };
      }
      try {
        await this.session.sendRequest({
          type: MiniappRequestType.MEETING_UPDATE_VIDEO_SOURCE,
          videoSource: validated
        });
      } catch (error) {
        mapHostError(error);
      }
    }
    async getState() {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_GET_STATE
        });
        if (result)
          this._applyState(result);
        return this.state;
      } catch (error) {
        mapHostError(error);
      }
    }
    onState(handler) {
      return this.session.on("meetingState", handler);
    }
    _applyState(event) {
      this._state = {
        state: event.state,
        muted: Boolean(event.muted),
        error: event.error,
        endReason: parseMeetingEndReason(event.endReason),
        meetingUrl: event.meetingUrl,
        provider: event.provider,
        audioSource: event.audioSource,
        audioSourceReason: event.audioSourceReason,
        activeStream: event.activeStream,
        audioSafety: event.audioSafety,
        mediaSource: parseMeetingMediaSource(event.mediaSource),
        participants: parseMeetingParticipants(event.participants),
        capabilities: parseMeetingCapabilities(event.capabilities) ?? this._state.capabilities,
        softap: parseMeetingSoftApProgress(event.softap),
        recovery: parseMeetingRecovery(event.recovery) ?? this._state.recovery
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/llm.js
  var LLM_GENERATE_TIMEOUT_MS = 300000;

  class LlmModule {
    constructor(session) {
      this.session = session;
    }
    availability() {
      return this.session.sendRequest({ type: MiniappRequestType.LLM_AVAILABILITY });
    }
    generate(req) {
      return this.session.sendRequest({
        type: MiniappRequestType.LLM_GENERATE,
        instructions: req.instructions,
        prompt: req.prompt,
        schema: req.schema,
        maxTokens: req.maxTokens,
        temperature: req.temperature,
        llmRequestId: req.requestId
      }, { timeoutMs: LLM_GENERATE_TIMEOUT_MS });
    }
    async cancel(requestId) {
      await this.session.sendRequest({ type: MiniappRequestType.LLM_CANCEL, llmRequestId: requestId });
    }
  }

  // ../../mobile/modules/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.hostFeatures = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.configurationState = {};
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.configuration = new ConfigurationModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.meeting = new MeetingModule(this);
      this.camera = new CameraModule(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
      this.llm = new LlmModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _getConfiguration() {
      return { ...this.configurationState };
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler, options = {}) {
      return this.events.subscribe(streamType, handler, options);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          this.hostFeatures = ack.hostFeatures ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          this.configurationState = Object.freeze({ ...ack.configuration });
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappResponseType.MEETING_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            muted: Boolean(payload.muted),
            error: payload.error,
            meetingUrl: payload.meetingUrl,
            provider: payload.provider,
            audioSource: payload.audioSource,
            audioSourceReason: payload.audioSourceReason,
            activeStream: payload.activeStream,
            audioSafety: payload.audioSafety,
            mediaSource: parseMeetingMediaSource(payload.mediaSource),
            endReason: parseMeetingEndReason(payload.endReason),
            participants: parseMeetingParticipants(payload.participants),
            capabilities: parseMeetingCapabilities(payload.capabilities),
            softap: parseMeetingSoftApProgress(payload.softap),
            recovery: parseMeetingRecovery(payload.recovery)
          };
          this.meeting._applyState(event);
          this.emitter.emit("meetingState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data, payload.transcriptionRoute);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/background/display/glasses.ts
  var KIND_LABEL = {
    concept: "CONCEPT",
    bio: "BIO",
    answer: "ANSWER",
    suggestion: "SUGGESTION"
  };
  function cellWidth(ch) {
    return /[㐀-鿿豈-﫿぀-ヿ가-힯　-〿＀-￯]/.test(ch) ? 2 : 1;
  }
  function wrapLensText(text, cells, maxLines) {
    const words = text.split(/\s+/).filter((w) => w.length > 0);
    const lines = [];
    let cur = "";
    let curW = 0;
    const pushWord = (w) => {
      const wW = [...w].reduce((a, c) => a + cellWidth(c), 0);
      const gap = cur ? 1 : 0;
      if (curW + gap + wW <= cells) {
        cur = cur ? cur + " " + w : w;
        curW += gap + wW;
        return true;
      }
      return false;
    };
    let dropped = false;
    for (let i = 0;i < words.length; i++) {
      const word = words[i];
      if (pushWord(word))
        continue;
      if (cur) {
        lines.push(cur);
        cur = "";
        curW = 0;
        if (lines.length >= maxLines) {
          dropped = true;
          break;
        }
      }
      let rest = word;
      while ([...rest].reduce((a, c) => a + cellWidth(c), 0) > cells && lines.length < maxLines) {
        let take = 0;
        let w = 0;
        for (const ch of rest) {
          if (w + cellWidth(ch) > cells)
            break;
          w += cellWidth(ch);
          take += ch.length;
        }
        lines.push(rest.slice(0, take));
        rest = rest.slice(take);
      }
      if (lines.length >= maxLines) {
        dropped = true;
        break;
      }
      cur = rest;
      curW = [...rest].reduce((a, c) => a + cellWidth(c), 0);
    }
    if (lines.length < maxLines && cur)
      lines.push(cur);
    if (dropped && lines.length > 0) {
      const last = lines[lines.length - 1];
      lines[lines.length - 1] = last.length > 1 ? last.slice(0, -1) + "…" : last + "…";
    }
    return lines;
  }

  class GlassesDisplay {
    render;
    width;
    height;
    now;
    defer;
    cues = [];
    pageIndex = -1;
    pendingCount = 0;
    cueVisible = false;
    pinned = false;
    liveText = "";
    dismissArmed = false;
    autoPopup;
    liveLine;
    cueDurationMs;
    constructor(render, options = {}) {
      this.render = render;
      this.width = options.width ?? 576;
      this.height = options.height ?? 288;
      this.now = options.now ?? Date.now;
      this.defer = options.defer ?? ((fn, ms) => setTimeout(fn, ms));
      this.autoPopup = options.autoPopup ?? true;
      this.liveLine = options.liveLine ?? false;
      this.cueDurationMs = options.cueDurationMs ?? 8000;
    }
    get cellsPerLine() {
      return Math.floor(this.width / 8.5);
    }
    get bodyLines() {
      return this.liveLine ? 3 : 4;
    }
    addCue(cue) {
      this.cues.push(cue);
      if (this.autoPopup) {
        this.pageIndex = this.cues.length - 1;
        this.showCue();
      } else {
        this.pendingCount += 1;
        this.renderFrame();
      }
    }
    setLiveLine(final) {
      this.liveText = final ? final.translation ?? final.text : "";
      if (!this.cueVisible)
        this.renderFrame();
    }
    tap() {
      if (this.pendingCount > 0 || this.cues.length > 0) {
        this.pendingCount = 0;
        this.pageIndex = this.cues.length - 1;
        this.showCue();
      }
    }
    pageBack() {
      if (this.cues.length === 0)
        return;
      const idx = this.pageIndex < 0 ? this.cues.length - 1 : this.pageIndex;
      this.pageIndex = Math.max(0, idx - 1);
      this.pin();
    }
    pageForward() {
      if (this.cues.length === 0)
        return;
      const idx = this.pageIndex < 0 ? this.cues.length - 1 : this.pageIndex;
      this.pageIndex = Math.min(this.cues.length - 1, idx + 1);
      this.pin();
    }
    clear() {
      this.cueVisible = false;
      this.pinned = false;
      this.pendingCount = 0;
      this.render([]);
    }
    get cueCount() {
      return this.cues.length;
    }
    pin() {
      this.pinned = true;
      this.cueVisible = true;
      this.renderFrame();
    }
    showCue() {
      this.cueVisible = true;
      this.pinned = false;
      this.renderFrame();
      if (!this.dismissArmed) {
        this.dismissArmed = true;
        this.defer(() => {
          this.dismissArmed = false;
          if (this.cueVisible && !this.pinned) {
            this.cueVisible = false;
            this.renderFrame();
          }
        }, this.cueDurationMs);
      }
    }
    renderFrame() {
      const els = [];
      const cells = this.cellsPerLine;
      if (this.cueVisible && this.cues.length > 0) {
        const idx = this.pageIndex < 0 ? this.cues.length - 1 : this.pageIndex;
        const cue = this.cues[idx];
        const header = `${KIND_LABEL[cue.kind]} · ${cue.title}` + (this.pinned && this.cues.length > 1 ? `  (${idx + 1}/${this.cues.length})` : "") + (cue.languageNote ? "  ⓘ" : "");
        const titleLines = wrapLensText(header, cells, 1);
        const bodyLines = wrapLensText(cue.body, cells, this.bodyLines);
        const text = [...titleLines, ...bodyLines];
        els.push({
          type: "text",
          id: "conversate-cue",
          box: { x: 8, y: 8, w: this.width - 16, h: this.height - (this.liveLine ? 48 : 16) },
          text: text.join(`
`),
          style: { overflow: "ellipsis", breakMode: "word" }
        });
        if (cue.languageNote) {
          els.push({
            type: "text",
            id: "conversate-cue-lang",
            box: { x: 8, y: this.height - (this.liveLine ? 72 : 40), w: this.width - 16, h: 24 },
            text: wrapLensText(cue.languageNote, cells, 1).join(""),
            style: { overflow: "ellipsis" }
          });
        }
      } else if (this.pendingCount > 0) {
        els.push({
          type: "text",
          id: "conversate-pending",
          box: { x: 8, y: 8, w: this.width - 16, h: 40 },
          text: `● ${this.pendingCount} new cue${this.pendingCount > 1 ? "s" : ""}`
        });
      }
      if (this.liveLine && this.liveText) {
        els.push({
          type: "text",
          id: "conversate-live",
          box: { x: 8, y: this.height - 32, w: this.width - 16, h: 28 },
          text: wrapLensText(this.liveText, cells, 1).join(""),
          style: { overflow: "ellipsis" }
        });
      }
      this.render(els);
    }
  }

  // src/background/cues/scheduler.ts
  var QUESTION_TAIL = /[?？]\s*$|[嗎呢]\s*$/;
  var INTERROGATIVE_LEAD = /(?:^|[.!?。！？]\s*)(?:who|what|when|where|why|how|which|whose|whom|is|are|was|were|do|does|did|can|could|should|would|will|shall|may|might|是不是|為什麼|为什么|什麼|什么|怎麼|怎么|哪裡|哪里|誰|谁|何時|何时|多少)/i;
  var PRIORITY = {
    question: 3,
    prepnote: 2,
    volume: 1,
    cadence: 0
  };

  class CueScheduler {
    request;
    wordThreshold;
    cjkThreshold;
    cadenceMs;
    minSpacingMs;
    staleMs;
    staleFinals;
    prepKeywords;
    now;
    defer;
    enabled = false;
    finalsSeen = 0;
    wordsSinceCue = 0;
    cjkSinceCue = 0;
    finalsSinceCue = 0;
    lastCueAt = 0;
    lastDispatchAt = Number.NEGATIVE_INFINITY;
    inFlight = false;
    pending = null;
    retryArmed = false;
    constructor(request, options = {}) {
      this.request = request;
      this.wordThreshold = options.wordThreshold ?? 40;
      this.cjkThreshold = options.cjkThreshold ?? 80;
      this.cadenceMs = options.cadenceMs ?? 20000;
      this.minSpacingMs = options.minSpacingMs ?? 6000;
      this.staleMs = options.staleMs ?? 30000;
      this.staleFinals = options.staleFinals ?? 2;
      this.prepKeywords = (options.prepKeywords ?? []).map((k) => k.toLowerCase());
      this.now = options.now ?? Date.now;
      this.defer = options.defer ?? ((fn, ms) => setTimeout(fn, ms));
    }
    setEnabled(enabled) {
      this.enabled = enabled;
      if (!enabled)
        this.pending = null;
    }
    reset() {
      this.finalsSeen = 0;
      this.wordsSinceCue = 0;
      this.cjkSinceCue = 0;
      this.finalsSinceCue = 0;
      this.lastCueAt = this.now();
      this.lastDispatchAt = Number.NEGATIVE_INFINITY;
      this.inFlight = false;
      this.pending = null;
      this.retryArmed = false;
    }
    setPrepKeywords(keywords) {
      this.prepKeywords.length = 0;
      for (const k of keywords)
        this.prepKeywords.push(k.toLowerCase());
    }
    onFinal(text) {
      this.finalsSeen += 1;
      this.finalsSinceCue += 1;
      this.wordsSinceCue += countWords(text);
      this.cjkSinceCue += countCjk(text);
      if (!this.enabled)
        return;
      if (isQuestion(text)) {
        this.trigger({ kind: "question", cause: text });
        return;
      }
      if (this.prepKeywords.length > 0 && containsKeyword(text, this.prepKeywords)) {
        this.trigger({ kind: "prepnote", cause: text });
        return;
      }
      if (this.wordsSinceCue >= this.wordThreshold || this.cjkSinceCue >= this.cjkThreshold) {
        this.trigger({ kind: "volume" });
        return;
      }
      if (this.finalsSinceCue > 0 && this.now() - this.lastCueAt >= this.cadenceMs) {
        this.trigger({ kind: "cadence" });
      }
    }
    tick() {
      if (!this.enabled)
        return;
      if (this.finalsSinceCue > 0 && this.now() - this.lastCueAt >= this.cadenceMs) {
        this.trigger({ kind: "cadence" });
      }
      this.maybeDispatch();
    }
    requestSettled(mark) {
      this.inFlight = false;
      const stale = this.finalsSeen - mark >= this.staleFinals;
      this.maybeDispatch();
      return { stale };
    }
    speechMark() {
      return this.finalsSeen;
    }
    get busy() {
      return this.inFlight;
    }
    trigger(t) {
      const candidate = { ...t, queuedAt: this.now(), mark: this.finalsSeen };
      if (!this.pending || PRIORITY[t.kind] >= PRIORITY[this.pending.kind]) {
        this.pending = candidate;
      }
      this.maybeDispatch();
    }
    maybeDispatch() {
      if (!this.enabled || this.inFlight || !this.pending)
        return;
      if (this.finalsSeen - this.pending.mark >= this.staleFinals || this.now() - this.pending.queuedAt > this.staleMs) {
        this.pending = null;
        return;
      }
      const wait = this.minSpacingMs - (this.now() - this.lastDispatchAt);
      if (wait > 0) {
        if (!this.retryArmed) {
          this.retryArmed = true;
          this.defer(() => {
            this.retryArmed = false;
            this.maybeDispatch();
          }, wait);
        }
        return;
      }
      const t = this.pending;
      this.pending = null;
      this.inFlight = true;
      this.lastCueAt = this.now();
      this.lastDispatchAt = this.now();
      this.wordsSinceCue = 0;
      this.cjkSinceCue = 0;
      this.finalsSinceCue = 0;
      this.request({ kind: t.kind, cause: t.cause });
    }
  }
  function isQuestion(text) {
    const t = text.trim();
    if (!t)
      return false;
    if (QUESTION_TAIL.test(t))
      return true;
    return INTERROGATIVE_LEAD.test(t);
  }
  function countWords(text) {
    let n = 0;
    for (const tok of text.split(/\s+/)) {
      if (/[\p{L}\p{N}]/u.test(tok) && !/^\p{Script=Han}+$/u.test(tok))
        n += 1;
    }
    return n;
  }
  function countCjk(text) {
    const m = text.match(/[㐀-鿿豈-﫿]/g);
    return m ? m.length : 0;
  }
  function containsKeyword(text, keywords) {
    const lower = text.toLowerCase();
    return keywords.some((k) => k.length > 0 && lower.includes(k));
  }

  // src/shared/languages.ts
  var TRADITIONAL_ZH_SUBTAGS = { hant: true, tw: true, hk: true, mo: true };
  function chineseScript(code) {
    const subtags = (code ?? "").toLowerCase().split("-");
    if (subtags[0] !== "zh")
      return null;
    return subtags.slice(1).some((s) => TRADITIONAL_ZH_SUBTAGS[s]) ? "hant" : "hans";
  }

  // src/background/cues/prompt.ts
  var TOKEN_BUDGET = {
    instructions: 250,
    prepNote: 900,
    runningSummary: 400,
    transcript: 1500,
    cueHistory: 120,
    output: 220
  };
  var CJK_RE = /[㐀-鿿豈-﫿぀-ヿ가-힯]/g;
  function estimateTokens(text) {
    const cjk = text.match(CJK_RE)?.length ?? 0;
    return Math.ceil(cjk / 1.5 + (text.length - cjk) / 4);
  }
  function trimFinalsToBudget(finals, budget) {
    const kept = [];
    let used = 0;
    for (let i = finals.length - 1;i >= 0; i--) {
      const f = finals[i];
      const cost = estimateTokens(f.text) + (f.translation ? estimateTokens(f.translation) : 0);
      if (used + cost > budget) {
        if (kept.length === 0) {
          kept.push({ ...f, text: tailByTokens(f.text, budget) });
        }
        break;
      }
      used += cost;
      kept.push(f);
    }
    return kept.reverse();
  }
  function tailByTokens(text, budget) {
    if (estimateTokens(text) <= budget)
      return text;
    let units = 0;
    const limit = budget * 3;
    let i = text.length;
    while (i > 0) {
      const ch = text[i - 1];
      units += /[㐀-鿿豈-﫿぀-ヿ가-힯]/.test(ch) ? 3 : 1;
      if (units > limit)
        break;
      i--;
    }
    return "…" + text.slice(i);
  }
  var CUE_SCHEMA = {
    type: "object",
    properties: {
      cues: {
        type: "array",
        maxItems: 2,
        items: {
          type: "object",
          properties: {
            kind: { enum: ["concept", "bio", "answer", "suggestion"] },
            title: { type: "string", description: "≤ 6 words" },
            body: { type: "string", description: "≤ 25 words" }
          },
          required: ["kind", "title", "body"]
        }
      }
    },
    required: ["cues"]
  };
  var CUE_INSTRUCTIONS = "You are Easy2Say, an on-device conversation assistant. From the live " + "transcript, produce at most two short cues that would genuinely help the " + "listener right now: a concept worth defining, a bio of a person or org " + "mentioned, an answer to a question just asked, or a suggestion for what " + "to say next. Use only the transcript, the prep note, and your own " + "knowledge — you have no internet access. Keep every title under 6 words " + "and every body under 25 words; they render on a tiny glasses display. " + "If nothing would be useful, return an empty cue list — silence beats " + "noise on a heads-up display. Never repeat a cue already shown (listed " + "under RECENT CUES).";
  function buildCuePrompt(input) {
    const budget = input.transcriptBudget ?? TOKEN_BUDGET.transcript;
    const finals = trimFinalsToBudget(input.finals, budget);
    const parts = [];
    parts.push(`Reply with cues written in ${input.cueLanguage}.`);
    if (input.runningSummary.trim()) {
      parts.push(`
CONVERSATION SO FAR (summary):
${input.runningSummary.trim()}`);
    }
    if (input.prepNoteExcerpt.trim()) {
      parts.push(`
PREP NOTE (user-provided context):
${input.prepNoteExcerpt.trim()}`);
    }
    if (input.recentCueTitles.length > 0) {
      parts.push(`
RECENT CUES (do not repeat):
${input.recentCueTitles.map((t) => `- ${t}`).join(`
`)}`);
    }
    if (finals.length > 0) {
      const lines = finals.map((f) => f.translation ? `${f.text}
  → ${f.translation}` : f.text);
      parts.push(`
RECENT TRANSCRIPT:
${lines.join(`
`)}`);
    } else {
      parts.push(`
RECENT TRANSCRIPT:
(none yet)`);
    }
    const prompt = parts.join(`
`);
    return {
      instructions: CUE_INSTRUCTIONS,
      prompt,
      schema: CUE_SCHEMA,
      maxTokens: TOKEN_BUDGET.output,
      estimatedTokens: estimateTokens(CUE_INSTRUCTIONS) + estimateTokens(prompt)
    };
  }
  var CUE_KINDS = { concept: true, bio: true, answer: true, suggestion: true };
  var CUE_TITLE_MAX_CHARS = 60;
  var CUE_BODY_MAX_CHARS = 200;
  var LEAK_BOUNDARY = /[<{}]|\\["\\/bfnrtu]/;
  var ZERO_WIDTH = /[\u200B-\u200D\uFEFF]/g;
  var ORPHAN_TAIL = /["'’”)\]>、，,;；:：·「『]+$/u;
  var countChar = (s, ch) => s.split(ch).length - 1;
  function sanitizeCueText(raw, maxChars = CUE_BODY_MAX_CHARS) {
    const boundary = LEAK_BOUNDARY.exec(raw);
    let s = boundary ? raw.slice(0, boundary.index) : raw;
    s = s.replace(ZERO_WIDTH, "").replace(/\s+/g, " ").trim();
    s = s.replace(ORPHAN_TAIL, "");
    while (s.endsWith("」") && countChar(s, "「") < countChar(s, "」"))
      s = s.slice(0, -1);
    while (s.endsWith("』") && countChar(s, "『") < countChar(s, "』"))
      s = s.slice(0, -1);
    s = s.trimEnd();
    if (s.length > maxChars)
      s = s.slice(0, maxChars).trimEnd();
    return s;
  }
  function parseCues(result, t, languageNote) {
    let root = result.json;
    if (root === undefined && typeof result.text === "string") {
      try {
        root = JSON.parse(result.text);
      } catch {
        return [];
      }
    }
    if (typeof root !== "object" || root === null)
      return [];
    const list = root.cues;
    if (!Array.isArray(list))
      return [];
    const cues = [];
    for (const item of list.slice(0, 2)) {
      const { kind, title, body } = item;
      if (typeof kind !== "string" || CUE_KINDS[kind] !== true)
        continue;
      if (typeof title !== "string" || typeof body !== "string")
        continue;
      const cleanTitle = sanitizeCueText(title, CUE_TITLE_MAX_CHARS);
      const cleanBody = sanitizeCueText(body, CUE_BODY_MAX_CHARS);
      if (!cleanTitle || !cleanBody)
        continue;
      cues.push({
        id: `cue-${t.toString(36)}-${cues.length}`,
        kind,
        title: cleanTitle,
        body: cleanBody,
        t,
        ...languageNote ? { languageNote } : {}
      });
    }
    return cues;
  }
  function decideCueLanguage(requested, supportedLanguages) {
    const supported = supportedLanguages ?? [];
    const match = findSupported(requested, supported);
    if (match)
      return { tag: match };
    const english = findSupported("en", supported);
    if (english) {
      return { tag: english, languageNote: `shown in English — on-device AI cannot write ${requested}` };
    }
    if (supported.length === 0)
      return { tag: requested };
    return { tag: requested, languageNote: `on-device AI may not support ${requested}` };
  }
  function findSupported(requested, supported) {
    const req = requested.toLowerCase();
    const reqScript = chineseScript(requested);
    const reqPrimary = req.split("-")[0];
    for (const tag of supported) {
      const t = tag.toLowerCase();
      if (t === req)
        return tag;
      if (t.split("-")[0] !== reqPrimary)
        continue;
      if (reqPrimary === "zh") {
        if (reqScript && chineseScript(tag) === reqScript)
          return tag;
      } else {
        return tag;
      }
    }
    return null;
  }

  // src/background/cues/dedupe.ts
  function normalizeCueTitle(title) {
    return title.toLowerCase().normalize("NFKC").replace(/[\p{P}\p{S}]+/gu, " ").replace(/\s+/g, " ").trim();
  }
  function isDuplicateCue(title, existing) {
    const norm = normalizeCueTitle(title);
    if (!norm)
      return true;
    return existing.some((c) => normalizeCueTitle(c.title) === norm);
  }
  function dedupeCues(incoming, existing) {
    const out = [];
    for (const cue of incoming) {
      if (isDuplicateCue(cue.title, existing) || isDuplicateCue(cue.title, out))
        continue;
      out.push(cue);
    }
    return out;
  }

  // src/background/cues/prepnote.ts
  var PREP_NOTE_MAX_CHARS = 5000;
  var CHUNK_CHARS = 300;
  var MAX_KEYWORDS = 200;
  function clampPrepNote(text) {
    return text.length > PREP_NOTE_MAX_CHARS ? text.slice(0, PREP_NOTE_MAX_CHARS) : text;
  }
  function extractKeywords(note) {
    const out = [];
    const seen = {};
    const push = (k) => {
      const key = k.toLowerCase();
      if (!seen[key] && out.length < MAX_KEYWORDS) {
        seen[key] = true;
        out.push(key);
      }
    };
    for (const m of note.matchAll(/[\p{L}\p{N}]{4,}/gu)) {
      if (!/^[㐀-鿿豈-﫿぀-ヿ가-힯]+$/.test(m[0]))
        push(m[0]);
    }
    for (const m of note.matchAll(/[㐀-鿿豈-﫿]{3,}/g))
      push(m[0]);
    return out;
  }
  function chunkPrepNote(note) {
    const chunks = [];
    for (const line of note.split(`
`)) {
      let rest = line.trim();
      while (rest.length > CHUNK_CHARS) {
        let cut = rest.lastIndexOf(" ", CHUNK_CHARS);
        if (cut < CHUNK_CHARS / 2)
          cut = CHUNK_CHARS;
        chunks.push(rest.slice(0, cut).trim());
        rest = rest.slice(cut).trim();
      }
      if (rest)
        chunks.push(rest);
    }
    return chunks;
  }
  function retrievePrepNote(note, queryText, tokenBudget) {
    if (!note.trim() || !queryText.trim())
      return "";
    const chunks = chunkPrepNote(note);
    const terms = queryTerms(queryText);
    if (terms.length === 0)
      return "";
    const scored = chunks.map((text, index) => ({ text, index, score: overlapScore(text, terms) })).filter((s) => s.score > 0).sort((a, b) => b.score - a.score || a.index - b.index);
    const picked = [];
    let used = 0;
    for (const s of scored) {
      const cost = estimateTokens(s.text);
      if (used + cost > tokenBudget)
        continue;
      used += cost;
      picked.push(s);
    }
    picked.sort((a, b) => a.index - b.index);
    return tailByTokens(picked.map((p) => p.text).join(`
…
`), tokenBudget);
  }
  function queryTerms(text) {
    const terms = [];
    const seen = {};
    const push = (t) => {
      if (!seen[t]) {
        seen[t] = true;
        terms.push(t);
      }
    };
    for (const m of text.toLowerCase().matchAll(/[\p{L}\p{N}]{3,}/gu)) {
      if (!/^[㐀-鿿豈-﫿぀-ヿ가-힯]+$/.test(m[0]))
        push(m[0]);
    }
    const cjk = text.match(/[㐀-鿿豈-﫿]+/g) ?? [];
    for (const run of cjk) {
      for (let i = 0;i + 2 <= run.length; i++)
        push(run.slice(i, i + 2));
    }
    return terms;
  }
  function overlapScore(chunk, terms) {
    const lower = chunk.toLowerCase();
    let score = 0;
    for (const t of terms) {
      if (lower.includes(t))
        score += 1;
    }
    return score;
  }

  // src/background/summary/running.ts
  var SUMMARY_SCHEMA = {
    type: "object",
    properties: {
      summary: {
        type: "string",
        description: "Running summary of the conversation so far: key facts, names, decisions, open questions. ≤ 60 words."
      }
    },
    required: ["summary"]
  };
  var SUMMARY_INSTRUCTIONS = "You maintain a running summary of a live conversation for an on-device " + "assistant. Merge the previous summary (if any) with the new transcript " + "lines into one compact brief: key facts, names and who they are, " + "decisions made, and questions still open. Drop filler. ≤ 60 words.";

  class RunningSummary {
    intervalMs;
    bufferTokenLimit;
    now;
    segments = [];
    buffer = [];
    bufferTokens = 0;
    lastSummarizedAt = 0;
    constructor(options = {}) {
      this.intervalMs = options.intervalMs ?? 4 * 60000;
      this.bufferTokenLimit = options.bufferTokenLimit ?? 1200;
      this.now = options.now ?? Date.now;
      this.lastSummarizedAt = this.now();
    }
    reset() {
      this.segments.length = 0;
      this.buffer = [];
      this.bufferTokens = 0;
      this.lastSummarizedAt = this.now();
    }
    add(final) {
      this.buffer.push(final);
      this.bufferTokens += estimateTokens(final.text) + (final.translation ? estimateTokens(final.translation) : 0);
    }
    due() {
      if (this.buffer.length === 0)
        return false;
      return this.bufferTokens > this.bufferTokenLimit || this.now() - this.lastSummarizedAt >= this.intervalMs;
    }
    pendingFinals() {
      return this.buffer;
    }
    promptText() {
      if (this.segments.length === 0)
        return "";
      const picked = [];
      let used = 0;
      for (let i = this.segments.length - 1;i >= 0; i--) {
        const cost = estimateTokens(this.segments[i]);
        if (used + cost > TOKEN_BUDGET.runningSummary)
          break;
        used += cost;
        picked.unshift(this.segments[i]);
      }
      return tailByTokens(picked.join(" "), TOKEN_BUDGET.runningSummary);
    }
    commit(summaryText) {
      const text = summaryText.trim();
      if (text)
        this.segments.push(text);
      this.buffer = [];
      this.bufferTokens = 0;
      this.lastSummarizedAt = this.now();
    }
    flushBuffer() {
      const out = this.buffer;
      this.buffer = [];
      this.bufferTokens = 0;
      return out;
    }
    buildRequest() {
      const prior = this.promptText();
      const lines = this.buffer.map((f) => f.text).join(`
`);
      const prompt = (prior ? `PREVIOUS SUMMARY:
${prior}

` : "") + `NEW TRANSCRIPT LINES:
${lines}

Update the running summary.`;
      return {
        instructions: SUMMARY_INSTRUCTIONS,
        prompt,
        schema: SUMMARY_SCHEMA,
        maxTokens: 160
      };
    }
  }

  // src/background/host.ts
  function llmErrorCode(err) {
    const text = typeof err === "object" && err !== null && "code" in err ? String(err.code) : err instanceof Error ? err.message : String(err);
    for (const code of [
      "LLM_UNAVAILABLE",
      "LLM_GUARDRAIL",
      "LLM_CONTEXT_EXCEEDED",
      "LLM_CANCELLED",
      "LLM_UNSUPPORTED_LANGUAGE"
    ]) {
      if (text.includes(code))
        return code;
    }
    return null;
  }
  function llmErrorReason(err) {
    if (typeof err === "object" && err !== null && "reason" in err) {
      const r = err.reason;
      if (typeof r === "string" && r)
        return r;
    }
    return;
  }
  function getLlm(session) {
    const candidate = session.llm;
    if (candidate && typeof candidate === "object" && typeof candidate.availability === "function" && typeof candidate.generate === "function") {
      return candidate;
    }
    return null;
  }
  function subscribeTranscription(session, language, handler) {
    const options = { forceLocal: true, engine: "auto" };
    return session.transcription.forLanguage(language, handler, options);
  }
  function subscribeTranslation(session, targetLanguage, handler) {
    return session.translation.to(targetLanguage, handler, { forceLocal: true });
  }
  function onSpeechUnavailable(session, handler) {
    return session.events.subscribe("local_translation_unavailable", (data) => {
      const reason = typeof data === "object" && data !== null && "reason" in data ? String(data.reason) : "unavailable";
      handler(reason || "unavailable");
    });
  }
  async function importTextFile(session) {
    try {
      const meta = await session.blob.importFile({ mimeType: "text/plain" });
      if (!meta)
        return { text: null };
      const bytes = await session.blob.bytes(meta.key);
      if (!bytes)
        return { text: null, error: "Could not read the selected file" };
      return { text: new TextDecoder().decode(bytes) };
    } catch (err) {
      return { text: null, error: err instanceof Error ? err.message : String(err) };
    }
  }
  var REVIEW_EXPORT_FOLDER = "Recordings/Easy2Say";
  var BLOB_EXPORT_REQUEST_TYPE = "miniapp_blob_export";
  async function exportMarkdown(session, filename, markdown) {
    const blob = session.blob;
    if (!blob)
      return { error: "On-device storage is unavailable on this host" };
    const bytes = new TextEncoder().encode(markdown);
    let meta = null;
    try {
      meta = await blob.set(`review-${Date.now().toString(36)}`, bytes, {
        mimeType: "text/markdown",
        name: filename,
        meta: { title: filename },
        export: { folder: REVIEW_EXPORT_FOLDER, filename, keepBlob: true }
      });
    } catch (err) {
      return { error: `Could not save the review: ${err instanceof Error ? err.message : String(err)}` };
    }
    const key = meta?.key;
    if (!key)
      return { error: "Could not save the review: the host returned no blob key" };
    if (typeof meta?.exportedTo === "string" && meta.exportedTo) {
      return { uri: meta.exportedTo, blobKey: key };
    }
    if (typeof meta?.exportError === "string" && meta.exportError) {
      return { blobKey: key, error: `Could not export to Files: ${meta.exportError}` };
    }
    const withExport = blob;
    if (typeof withExport.exportToFiles === "function") {
      try {
        const res = await withExport.exportToFiles(key, {
          folder: REVIEW_EXPORT_FOLDER,
          filename,
          keepBlob: true
        });
        if (res?.uri)
          return { uri: res.uri, blobKey: key };
        return { blobKey: key, error: "Could not export to Files: the host returned no destination" };
      } catch (err) {
        return { blobKey: key, error: `Could not export to Files: ${err instanceof Error ? err.message : String(err)}` };
      }
    }
    try {
      const res = await session.sendRequest({
        type: BLOB_EXPORT_REQUEST_TYPE,
        key,
        folder: REVIEW_EXPORT_FOLDER,
        filename,
        keepBlob: true
      });
      if (res?.uri)
        return { uri: res.uri, blobKey: key };
      return { blobKey: key, error: "Could not export to Files: the host returned no destination" };
    } catch {
      return {
        blobKey: key,
        error: "Saved to in-app history — this host cannot export to Files"
      };
    }
  }

  // src/background/review/review.ts
  var MAP_CHUNK_TOKENS = 2500;
  var MAP_MAX_TOKENS = 300;
  var REDUCE_MAX_TOKENS = 700;
  var MAP_SCHEMA = {
    type: "object",
    properties: {
      facts: { type: "array", maxItems: 12, items: { type: "string" } },
      actionItems: { type: "array", maxItems: 6, items: { type: "string" } }
    },
    required: ["facts", "actionItems"]
  };
  var REDUCE_SCHEMA = {
    type: "object",
    properties: {
      title: { type: "string", description: "≤ 8 words" },
      overview: { type: "string", description: "2-3 sentences" },
      highlights: { type: "array", maxItems: 8, items: { type: "string" } },
      details: { type: "array", maxItems: 12, items: { type: "string" } },
      nextSteps: { type: "array", maxItems: 8, items: { type: "string" } }
    },
    required: ["title", "overview", "highlights", "details", "nextSteps"]
  };
  var MAP_INSTRUCTIONS = "Summarize this excerpt of a conversation transcript into bullet facts " + "and action items. Facts: what was said/decided, names, numbers. Action " + "items: commitments and follow-ups. Be terse; each bullet ≤ 15 words.";
  var REDUCE_INSTRUCTIONS = "Combine these per-chunk summaries of one conversation into a final " + "review: a short title, a 2-3 sentence overview, highlights (the moments " + "worth remembering), details (facts worth keeping), and next steps " + "(commitments and follow-ups). Terse bullets, ≤ 15 words each.";
  function chunkTranscript(finals, budget = MAP_CHUNK_TOKENS) {
    const chunks = [];
    let cur = [];
    let used = 0;
    for (const f of finals) {
      const cost = estimateTokens(f.text) + (f.translation ? estimateTokens(f.translation) : 0);
      if (used + cost > budget && cur.length > 0) {
        chunks.push(cur);
        cur = [];
        used = 0;
      }
      cur.push(f);
      used += cost;
    }
    if (cur.length > 0)
      chunks.push(cur);
    return chunks;
  }
  async function mapChunk(run, chunk) {
    const lines = chunk.map((f) => f.translation ? `${f.text} (${f.translation})` : f.text).join(`
`);
    const res = await run({
      instructions: MAP_INSTRUCTIONS,
      prompt: `TRANSCRIPT EXCERPT:
${lines}`,
      schema: MAP_SCHEMA,
      maxTokens: MAP_MAX_TOKENS
    });
    return parseChunkSummary(res) ?? { facts: [], actionItems: [] };
  }
  function parseChunkSummary(res) {
    let root = res.json;
    if (root === undefined && typeof res.text === "string") {
      try {
        root = JSON.parse(res.text);
      } catch {
        return null;
      }
    }
    if (typeof root !== "object" || root === null)
      return null;
    const facts = "facts" in root ? root.facts : undefined;
    const actionItems = "actionItems" in root ? root.actionItems : undefined;
    const clean = (v) => Array.isArray(v) ? v.filter((f) => typeof f === "string").map((f) => sanitizeCueText(f)).filter((f) => f.length > 0) : [];
    return { facts: clean(facts), actionItems: clean(actionItems) };
  }
  function parseReviewSummary(res) {
    let root = res.json;
    if (root === undefined && typeof res.text === "string") {
      try {
        root = JSON.parse(res.text);
      } catch {
        return null;
      }
    }
    if (typeof root !== "object" || root === null)
      return null;
    const str = (v) => typeof v === "string" ? v : "";
    const arr = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string") : [];
    const r = root;
    const field = (name) => (name in r) ? r[name] : undefined;
    const title = sanitizeCueText(str(field("title")), 80);
    if (!title)
      return null;
    const clean = (v) => arr(v).map((x) => sanitizeCueText(x)).filter((x) => x.length > 0);
    return {
      title,
      overview: sanitizeCueText(str(field("overview")), 400),
      highlights: clean(field("highlights")),
      details: clean(field("details")),
      nextSteps: clean(field("nextSteps"))
    };
  }
  async function generateReview(input) {
    const { summarySegments, unsummarizedFinals, allFinals, cues, startedAt, llm, run } = input;
    const fallback = () => fallbackSummary(allFinals, cues, startedAt);
    if (!llm) {
      return {
        aiGenerated: false,
        label: "on-device AI unavailable",
        note: "On-device AI unavailable — transcript and cue list only.",
        summary: fallback()
      };
    }
    let guardrail = false;
    let unavailableReason = null;
    let contextExceeded = false;
    const classify = (err) => {
      const code = llmErrorCode(err);
      if (code === "LLM_GUARDRAIL")
        guardrail = true;
      else if (code === "LLM_CONTEXT_EXCEEDED")
        contextExceeded = true;
      else if (code === "LLM_UNAVAILABLE")
        unavailableReason = llmErrorReason(err) ?? "unknown";
    };
    const mappedTexts = [...summarySegments];
    const chunks = chunkTranscript(unsummarizedFinals);
    const chunkSummaries = [];
    for (const chunk of chunks) {
      try {
        chunkSummaries.push(await mapChunk(run, chunk));
      } catch (err) {
        classify(err);
        chunkSummaries.push({ facts: [], actionItems: [] });
      }
    }
    for (const cs of chunkSummaries) {
      const text = [...cs.facts, ...cs.actionItems.map((a) => `→ ${a}`)].join("; ");
      if (text)
        mappedTexts.push(text);
    }
    if (mappedTexts.length === 0) {
      return { aiGenerated: false, ...degradedNote(guardrail, unavailableReason, contextExceeded), summary: fallback() };
    }
    try {
      const res = await run({
        instructions: REDUCE_INSTRUCTIONS,
        prompt: `CHUNK SUMMARIES:
${mappedTexts.map((t, i) => `${i + 1}. ${t}`).join(`
`)}`,
        schema: REDUCE_SCHEMA,
        maxTokens: REDUCE_MAX_TOKENS
      });
      const summary = parseReviewSummary(res);
      if (summary)
        return { aiGenerated: true, summary };
    } catch (err) {
      classify(err);
    }
    return { aiGenerated: false, ...degradedNote(guardrail, unavailableReason, contextExceeded), summary: fallback() };
  }
  function degradedNote(guardrail, unavailableReason, contextExceeded) {
    if (guardrail) {
      return {
        label: "summary declined by the on-device safety filter",
        note: "Summary declined by the on-device safety filter — transcript and cue list only."
      };
    }
    if (unavailableReason !== null) {
      return {
        label: `on-device AI unavailable (${unavailableReason})`,
        note: `On-device AI unavailable: ${unavailableReason} — transcript and cue list only.`
      };
    }
    if (contextExceeded) {
      return {
        label: "transcript exceeded the on-device context window",
        note: "The transcript exceeded the on-device context window — transcript and cue list only."
      };
    }
    return {
      label: "summary generation failed",
      note: "Summary generation failed — transcript and cue list only."
    };
  }
  function fallbackSummary(finals, cues, startedAt) {
    const title = cues[0]?.title?.trim() || `Conversation · ${reviewStamp(startedAt)}`;
    return {
      title,
      overview: `${finals.length} transcript lines captured on-device.`,
      highlights: [],
      details: [],
      nextSteps: []
    };
  }
  function reviewStamp(startedAt) {
    const d = new Date(startedAt);
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
  function renderReviewMarkdown(args) {
    const { summary, cues, finals } = args;
    const d = new Date(args.startedAt);
    const pad = (n) => String(n).padStart(2, "0");
    const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    const out = [];
    out.push(`# ${summary.title}`);
    out.push("");
    out.push(`_Easy2Say · ${stamp} · on-device review${args.aiGenerated ? "" : ` (${args.label ?? "AI unavailable — transcript only"})`}_`);
    out.push("");
    out.push(`## Summary`);
    out.push("");
    if (args.aiGenerated && summary.overview)
      out.push(summary.overview, "");
    if (!args.aiGenerated && args.note)
      out.push(`> ${args.note}`, "");
    if (summary.highlights.length > 0) {
      out.push(`### Highlights`);
      for (const h of summary.highlights)
        out.push(`- ${h}`);
      out.push("");
    }
    if (summary.details.length > 0) {
      out.push(`### Details`);
      for (const s of summary.details)
        out.push(`- ${s}`);
      out.push("");
    }
    if (summary.nextSteps.length > 0) {
      out.push(`### Next Steps`);
      for (const s of summary.nextSteps)
        out.push(`- [ ] ${s}`);
      out.push("");
    }
    out.push(`## Cue List`);
    out.push("");
    if (cues.length === 0) {
      out.push(`_No cues were generated._`, "");
    } else {
      for (const c of [...cues].sort((a, b) => a.t - b.t)) {
        const cd = new Date(c.t);
        out.push(`- **${c.kind.toUpperCase()} · ${c.title}** — ${c.body} _(${pad(cd.getHours())}:${pad(cd.getMinutes())})_`);
      }
      out.push("");
    }
    out.push(`## Transcription`);
    out.push("");
    for (const f of finals) {
      const fd = new Date(f.t);
      out.push(`- [${pad(fd.getHours())}:${pad(fd.getMinutes())}] ${f.text}`);
      if (f.translation)
        out.push(`  - → ${f.translation}`);
    }
    out.push("");
    out.push(`---`);
    const footerBits = [`${finals.length} lines`, `${cues.length} cues`];
    if (args.guardrailSkips && args.guardrailSkips > 0) {
      footerBits.push(`${args.guardrailSkips} cue${args.guardrailSkips > 1 ? "s" : ""} skipped by on-device safety`);
    }
    footerBits.push(`generated entirely on-device`);
    out.push(`_${footerBits.join(" · ")}_`);
    out.push("");
    return out.join(`
`);
  }

  // src/background/history/store.ts
  var INDEX_KEY = "conversate.history.v1";
  var MAX_RECORDS = 100;

  class HistoryStore {
    session;
    index = null;
    constructor(session) {
      this.session = session;
    }
    async list() {
      if (this.index)
        return this.index;
      try {
        const raw = await this.session.storage.get(INDEX_KEY);
        const parsed = raw ? JSON.parse(raw) : [];
        this.index = Array.isArray(parsed) ? parsed.filter((r) => typeof r === "object" && r !== null && typeof r.id === "string") : [];
      } catch {
        this.index = [];
      }
      return this.index;
    }
    async add(record) {
      const list = await this.list();
      list.unshift(record);
      if (list.length > MAX_RECORDS) {
        const dropped = list.splice(MAX_RECORDS);
        for (const d of dropped) {
          try {
            await this.session.blob.delete(d.blobKey);
          } catch {}
        }
      }
      await this.persist();
    }
    async markdown(id) {
      const rec = (await this.list()).find((r) => r.id === id);
      if (!rec)
        return null;
      try {
        const bytes = await this.session.blob.bytes(rec.blobKey);
        return bytes ? new TextDecoder().decode(bytes) : null;
      } catch {
        return null;
      }
    }
    async delete(id) {
      const list = await this.list();
      const idx = list.findIndex((r) => r.id === id);
      if (idx < 0)
        return;
      const [rec] = list.splice(idx, 1);
      try {
        await this.session.blob.delete(rec.blobKey);
      } catch {}
      await this.persist();
    }
    async search(query) {
      const q = query.trim().toLowerCase();
      const list = await this.list();
      if (!q)
        return list;
      return list.filter((r) => r.title.toLowerCase().includes(q));
    }
    async markExported(id) {
      const rec = (await this.list()).find((r) => r.id === id);
      if (rec && !rec.exported) {
        rec.exported = true;
        await this.persist();
      }
    }
    async persist() {
      try {
        await this.session.storage.set(INDEX_KEY, JSON.stringify(this.index ?? []));
      } catch {}
    }
  }

  // src/background/ConversateController.ts
  var DEFAULT_SETTINGS = {
    language: "en",
    translationEnabled: false,
    targetLanguage: "zh-TW",
    cuesEnabled: true,
    autoPopup: true,
    cueDurationSec: 8,
    liveTranscriptOnGlasses: false,
    cueLanguage: "auto",
    micSource: "auto"
  };
  var STORAGE_KEYS = {
    settings: "conversate.settings.v1",
    prepNote: "conversate.prepnote.v1"
  };
  var PRIORITY_CUE = 10;
  var PRIORITY_SUMMARY = 1;

  class ConversateController {
    session;
    started = false;
    unsubs = [];
    ui;
    settings = { ...DEFAULT_SETTINGS };
    prepNote = "";
    state = "idle";
    transcript = [];
    cues = [];
    ai = { available: false };
    speech = { ok: true };
    reviewState = null;
    guardrailSkips = 0;
    sessionStartedAt = 0;
    lastMarkdown = null;
    speechCleanup = null;
    micLease = null;
    tickTimer = null;
    llm;
    llmSupportedLanguages;
    llmQueue = [];
    llmQueueSeq = 0;
    llmBusy = false;
    scheduler;
    runningSummary = new RunningSummary;
    glasses;
    history;
    constructor(session) {
      this.session = session;
      this.llm = getLlm(session);
      this.history = new HistoryStore(session);
      this.scheduler = new CueScheduler((trigger) => this.onCueTrigger(trigger));
      const caps = session.capabilities?.display;
      this.glasses = new GlassesDisplay((els) => void session.display.render(els), {
        width: caps?.width ?? 576,
        height: caps?.height ?? 288
      });
    }
    async start() {
      if (this.started)
        return;
      this.started = true;
      this.ui = this.session.ui;
      await this.loadState();
      this.applySettings();
      this.probeLlm();
      this.registerUiHandlers();
      this.registerActions();
      this.subscribeSpeechStatus();
      this.subscribeTouch();
      this.unsubs.push(this.ui.onOpen(() => {
        this.sendSnapshot();
      }));
      try {
        this.unsubs.push(this.session.onBeforeDisconnect(() => this.stop()));
      } catch {}
      console.log(`Easy2Say: started (llm=${this.llm ? "present" : "absent"})`);
    }
    stop() {
      this.teardownSession();
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.length = 0;
      this.started = false;
    }
    async startSession() {
      if (this.state === "running")
        return;
      this.transcript = [];
      this.cues = [];
      this.guardrailSkips = 0;
      this.reviewState = null;
      this.sessionStartedAt = Date.now();
      this.scheduler.reset();
      this.scheduler.setPrepKeywords(extractKeywords(this.prepNote));
      this.runningSummary.reset();
      this.speech = { ok: true };
      this.subscribeSpeech();
      this.scheduler.setEnabled(this.settings.cuesEnabled);
      this.setState("running");
      this.tickTimer = setInterval(() => this.scheduler.tick(), 1000);
    }
    pauseSession() {
      if (this.state !== "running")
        return;
      this.releaseSpeech();
      this.scheduler.setEnabled(false);
      this.setState("paused");
    }
    resumeSession() {
      if (this.state !== "paused")
        return;
      this.subscribeSpeech();
      this.scheduler.setEnabled(this.settings.cuesEnabled);
      this.setState("running");
    }
    async endSession() {
      if (this.state === "idle" || this.state === "reviewing")
        return;
      this.releaseSpeech();
      this.scheduler.setEnabled(false);
      this.glasses.clear();
      if (this.tickTimer) {
        clearInterval(this.tickTimer);
        this.tickTimer = null;
      }
      this.setState("reviewing");
      this.reviewState = { ready: false, exported: false };
      this.broadcastReview();
      const unsummarized = this.runningSummary.flushBuffer();
      const result = await generateReview({
        summarySegments: [...this.runningSummary.segments],
        unsummarizedFinals: unsummarized,
        allFinals: this.transcript,
        cues: this.cues,
        startedAt: this.sessionStartedAt,
        llm: this.llm,
        run: (req) => this.enqueueLlm(() => this.llm.generate(req), PRIORITY_SUMMARY)
      });
      const markdown = renderReviewMarkdown({
        title: result.summary.title,
        startedAt: this.sessionStartedAt,
        summary: result.summary,
        cues: this.cues,
        finals: this.transcript,
        aiGenerated: result.aiGenerated,
        note: result.note,
        label: result.label,
        guardrailSkips: this.guardrailSkips
      });
      const d = new Date(this.sessionStartedAt);
      const pad = (n) => String(n).padStart(2, "0");
      const safeTitle = result.summary.title.replace(/[\\/:*?"<>|]/g, "").slice(0, 60).trim() || "session";
      const filename = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}${pad(d.getMinutes())} Easy2Say ${safeTitle}.md`;
      const exportResult = await exportMarkdown(this.session, filename, markdown);
      const record = {
        id: `sess-${this.sessionStartedAt.toString(36)}`,
        startedAt: this.sessionStartedAt,
        title: result.summary.title,
        blobKey: exportResult.blobKey ?? "",
        cueCount: this.cues.length,
        finalCount: this.transcript.length,
        exported: Boolean(exportResult.uri)
      };
      if (record.blobKey) {
        await this.history.add(record);
        this.lastMarkdown = { id: record.id, markdown };
      }
      this.reviewState = {
        ready: true,
        exported: Boolean(exportResult.uri),
        exportMessage: exportResult.error
      };
      this.broadcastReview();
      this.broadcastHistory();
      this.setState("idle");
    }
    teardownSession() {
      this.releaseSpeech();
      if (this.tickTimer) {
        clearInterval(this.tickTimer);
        this.tickTimer = null;
      }
      this.scheduler.setEnabled(false);
      this.llmQueue = [];
    }
    releaseSpeech() {
      if (this.speechCleanup) {
        try {
          this.speechCleanup();
        } catch {}
        this.speechCleanup = null;
      }
      if (this.micLease) {
        this.micLease.release().catch(() => {});
        this.micLease = null;
      }
    }
    subscribeSpeech() {
      this.releaseSpeech();
      try {
        if (this.settings.micSource !== "auto") {
          this.session.mic.acquire({ source: this.settings.micSource, useCase: "transcription" }).then((lease) => {
            this.micLease = lease;
          }).catch(() => {});
        }
        if (this.settings.translationEnabled) {
          this.speechCleanup = subscribeTranslation(this.session, this.settings.targetLanguage, (d) => this.onTranslation(d));
        } else {
          this.speechCleanup = subscribeTranscription(this.session, this.settings.language, (d) => this.onTranscription(d));
        }
      } catch (err) {
        this.speech = { ok: false, reason: err instanceof Error ? err.message : String(err) };
        this.ui.send("conversate:speech-status", { ...this.speech });
      }
    }
    subscribeSpeechStatus() {
      try {
        this.unsubs.push(onSpeechUnavailable(this.session, (reason) => {
          this.speech = { ok: false, reason };
          this.ui.send("conversate:speech-status", { ...this.speech });
        }));
      } catch {}
    }
    onTranscription(d) {
      if (!d.isFinal || this.state !== "running")
        return;
      this.addFinal({ t: Date.now(), text: d.text });
    }
    onTranslation(d) {
      if (!d.isFinal || this.state !== "running")
        return;
      const original = d.originalText?.trim();
      this.addFinal({
        t: Date.now(),
        text: original && original.length > 0 ? original : d.text,
        translation: original && original.length > 0 ? d.text : undefined
      });
    }
    addFinal(f) {
      this.transcript.push(f);
      this.runningSummary.add(f);
      this.scheduler.onFinal(f.text);
      this.glasses.setLiveLine(f);
      this.ui.send("conversate:final", f);
      if (this.runningSummary.due())
        this.enqueueSummary();
    }
    onCueTrigger(trigger) {
      if (!this.llm) {
        this.setAi({ available: false, reason: "unknown" });
        this.scheduler.requestSettled(this.scheduler.speechMark());
        return;
      }
      const mark = this.scheduler.speechMark();
      this.enqueueLlm(() => this.generateCue(trigger, mark), PRIORITY_CUE);
    }
    async generateCue(trigger, mark, transcriptBudget) {
      const llm = this.llm;
      const requested = this.settings.cueLanguage === "auto" ? this.settings.language : this.settings.cueLanguage;
      const lang = decideCueLanguage(requested, this.llmSupportedLanguages);
      const lastFinals = this.transcript.slice(-3);
      const prepExcerpt = retrievePrepNote(this.prepNote, lastFinals.map((f) => f.text).join(`
`), TOKEN_BUDGET.prepNote);
      const prompt = buildCuePrompt({
        finals: this.transcript,
        runningSummary: this.runningSummary.promptText(),
        prepNoteExcerpt: prepExcerpt,
        recentCueTitles: this.cues.slice(-8).map((c) => c.title),
        cueLanguage: lang.tag,
        transcriptBudget
      });
      try {
        const res = await llm.generate({
          instructions: prompt.instructions,
          prompt: prompt.prompt,
          schema: prompt.schema,
          maxTokens: prompt.maxTokens,
          requestId: `cue-${mark}`
        });
        const { stale } = this.scheduler.requestSettled(mark);
        if (stale)
          return;
        this.setAi({ available: true, proven: true });
        const fresh = dedupeCues(parseCues(res, Date.now(), lang.languageNote), this.cues);
        for (const cue of fresh)
          this.addCue(cue);
      } catch (err) {
        this.scheduler.requestSettled(mark);
        const code = llmErrorCode(err);
        if (code === "LLM_GUARDRAIL") {
          this.guardrailSkips += 1;
        } else if (code === "LLM_CONTEXT_EXCEEDED" && transcriptBudget === undefined) {
          const retryMark = this.scheduler.speechMark();
          await this.generateCue(trigger, retryMark, Math.floor(TOKEN_BUDGET.transcript / 2));
        } else if (code === "LLM_UNAVAILABLE") {
          const avail = await llm.availability().catch(() => null);
          if (!avail || !avail.available) {
            this.setAi({ available: false, reason: llmErrorReason(err) ?? avail?.reason ?? "unknown" });
          }
        } else if (code === "LLM_UNSUPPORTED_LANGUAGE") {
          this.llmSupportedLanguages = (await llm.availability().catch(() => null))?.supportedLanguages ?? ["en"];
        }
      }
    }
    addCue(cue) {
      this.cues.push(cue);
      this.glasses.addCue(cue);
      this.ui.send("conversate:cue", cue);
    }
    enqueueSummary() {
      if (!this.llm)
        return;
      const req = this.runningSummary.buildRequest();
      this.enqueueLlm(async () => {
        try {
          const res = await this.llm.generate({ ...req, requestId: `sum-${Date.now().toString(36)}` });
          const text = extractSummaryText(res);
          this.runningSummary.commit(text ?? "");
        } catch {
          this.runningSummary.commit("");
        }
      }, PRIORITY_SUMMARY);
    }
    enqueueLlm(fn, priority) {
      const { promise, resolve, reject } = Promise.withResolvers();
      this.llmQueue.push({
        priority,
        seq: this.llmQueueSeq++,
        run: async () => {
          try {
            resolve(await fn());
          } catch (err) {
            reject(err);
          }
        }
      });
      this.llmQueue.sort((a, b) => b.priority - a.priority || a.seq - b.seq);
      this.pumpLlm();
      return promise;
    }
    async pumpLlm() {
      if (this.llmBusy)
        return;
      const job = this.llmQueue.shift();
      if (!job)
        return;
      this.llmBusy = true;
      try {
        await job.run();
      } finally {
        this.llmBusy = false;
        if (this.llmQueue.length > 0)
          this.pumpLlm();
      }
    }
    async probeLlm() {
      if (!this.llm) {
        this.setAi({ available: false, reason: "unknown" });
        return;
      }
      try {
        const avail = await this.llm.availability();
        this.llmSupportedLanguages = avail.supportedLanguages;
        this.setAi({ available: avail.available, reason: avail.reason });
      } catch {}
    }
    setAi(ai) {
      const changed = ai.available !== this.ai.available || ai.reason !== this.ai.reason;
      this.ai = { ...this.ai, ...ai };
      if (changed)
        this.ui.send("conversate:ai-status", { ...this.ai });
    }
    subscribeTouch() {
      try {
        this.unsubs.push(this.session.input.onTouch((d) => {
          if (this.state !== "running" && this.state !== "paused")
            return;
          switch (d.kind) {
            case "single_tap":
              this.glasses.tap();
              break;
            case "double_tap":
              this.endSession();
              break;
            case "swipe_up":
              this.glasses.pageBack();
              break;
            case "swipe_down":
              this.glasses.pageForward();
              break;
          }
        }));
      } catch {}
    }
    async loadState() {
      try {
        const raw = await this.session.storage.get(STORAGE_KEYS.settings);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (typeof parsed === "object" && parsed !== null) {
            this.settings = { ...DEFAULT_SETTINGS, ...parsed };
          }
        }
      } catch {}
      try {
        this.prepNote = clampPrepNote(await this.session.storage.get(STORAGE_KEYS.prepNote) ?? "");
      } catch {
        this.prepNote = "";
      }
    }
    applySettings() {
      this.glasses.autoPopup = this.settings.autoPopup;
      this.glasses.liveLine = this.settings.liveTranscriptOnGlasses;
      this.glasses.cueDurationMs = this.settings.cueDurationSec * 1000;
    }
    async persistSettings() {
      try {
        await this.session.storage.set(STORAGE_KEYS.settings, JSON.stringify(this.settings));
      } catch {}
      this.ui.send("conversate:settings", { ...this.settings });
    }
    async setPrepNote(text) {
      this.prepNote = clampPrepNote(text);
      this.scheduler.setPrepKeywords(extractKeywords(this.prepNote));
      try {
        await this.session.storage.set(STORAGE_KEYS.prepNote, this.prepNote);
      } catch {}
      this.ui.send("conversate:prep-note", { text: this.prepNote });
    }
    setState(state) {
      this.state = state;
      this.ui.send("conversate:state", { state });
    }
    broadcastReview() {
      if (this.reviewState)
        this.ui.send("conversate:review", { ...this.reviewState });
    }
    async broadcastHistory() {
      this.ui.send("conversate:history", { history: await this.history.list() });
    }
    async sendSnapshot() {
      const snapshot = {
        state: this.state,
        settings: { ...this.settings },
        prepNote: this.prepNote,
        cues: [...this.cues],
        transcript: this.transcript.slice(-200),
        ai: { ...this.ai },
        speech: { ...this.speech },
        review: this.reviewState ? { ...this.reviewState } : null,
        history: await this.history.list()
      };
      this.ui.send("conversate:snapshot", snapshot);
    }
    registerUiHandlers() {
      const on = this.ui.on.bind(this.ui);
      this.unsubs.push(on("conversate:start", () => void this.startSession()), on("conversate:pause", () => this.pauseSession()), on("conversate:resume", () => this.resumeSession()), on("conversate:end", () => void this.endSession()), on("conversate:request-snapshot", () => void this.sendSnapshot()), on("conversate:set-language", (p) => {
        this.settings.language = p.language;
        this.persistSettings();
        if (this.state === "running")
          this.subscribeSpeech();
      }), on("conversate:set-translation", (p) => {
        this.settings.translationEnabled = p.enabled;
        if (p.targetLanguage)
          this.settings.targetLanguage = p.targetLanguage;
        this.persistSettings();
        if (this.state === "running")
          this.subscribeSpeech();
      }), on("conversate:set-cues-enabled", (p) => {
        this.settings.cuesEnabled = p.enabled;
        this.scheduler.setEnabled(p.enabled && this.state === "running");
        this.persistSettings();
      }), on("conversate:set-auto-popup", (p) => {
        this.settings.autoPopup = p.enabled;
        this.glasses.autoPopup = p.enabled;
        this.persistSettings();
      }), on("conversate:set-cue-duration", (p) => {
        const s = Math.min(60, Math.max(2, Math.round(p.seconds)));
        this.settings.cueDurationSec = s;
        this.glasses.cueDurationMs = s * 1000;
        this.persistSettings();
      }), on("conversate:set-live-transcript", (p) => {
        this.settings.liveTranscriptOnGlasses = p.enabled;
        this.glasses.liveLine = p.enabled;
        this.persistSettings();
      }), on("conversate:set-cue-language", (p) => {
        this.settings.cueLanguage = p.cueLanguage;
        this.persistSettings();
      }), on("conversate:set-mic-source", (p) => {
        this.settings.micSource = p.micSource;
        this.persistSettings();
      }), on("conversate:set-prep-note", (p) => void this.setPrepNote(p.text)), on("conversate:delete-history", (p) => {
        this.history.delete(p.id).then(() => this.broadcastHistory());
      }));
      const handle = this.ui.handle.bind(this.ui);
      this.unsubs.push(handle("conversate:import-prep-note", async () => {
        const res = await importTextFile(this.session);
        if (res.text !== null)
          await this.setPrepNote(res.text.slice(0, PREP_NOTE_MAX_CHARS));
        return { text: res.text !== null ? this.prepNote : null, error: res.error };
      }), handle("conversate:get-review", async (p) => {
        if (this.lastMarkdown && this.lastMarkdown.id === p.id) {
          return { markdown: this.lastMarkdown.markdown };
        }
        const md = await this.history.markdown(p.id);
        return { markdown: md, error: md === null ? "Review not found on this device" : undefined };
      }), handle("conversate:export-review", async (p) => {
        const md = this.lastMarkdown && this.lastMarkdown.id === p.id ? this.lastMarkdown.markdown : await this.history.markdown(p.id);
        if (md === null)
          return { error: "Review not found on this device" };
        const rec = (await this.history.list()).find((r) => r.id === p.id);
        const res = await exportMarkdown(this.session, rec ? `${rec.title}.md` : "conversate.md", md);
        if (res.uri) {
          await this.history.markExported(p.id);
          await this.broadcastHistory();
          return { uri: res.uri };
        }
        return { error: res.error ?? "Export failed" };
      }));
    }
    registerActions() {
      try {
        this.unsubs.push(this.session.actions.handle("start_conversate", (params) => this.startConversateAction(params)));
      } catch (err) {
        console.log("Easy2Say: failed to register actions", err);
      }
    }
    async startConversateAction(params) {
      if (typeof params.language === "string" && params.language.trim()) {
        this.settings.language = params.language.trim();
      }
      if (typeof params.targetLanguage === "string" && params.targetLanguage.trim()) {
        this.settings.targetLanguage = params.targetLanguage.trim();
        this.settings.translationEnabled = true;
      }
      await this.persistSettings();
      await this.startSession();
      return {
        language: this.settings.language,
        targetLanguage: this.settings.targetLanguage,
        status: this.state === "running" ? "running" : "failed"
      };
    }
  }
  function extractSummaryText(res) {
    let root = res.json;
    if (root === undefined && typeof res.text === "string") {
      try {
        root = JSON.parse(res.text);
      } catch {
        return null;
      }
    }
    if (typeof root !== "object" || root === null)
      return null;
    const s = root.summary;
    return typeof s === "string" && s.trim() ? s.trim() : null;
  }

  // src/background/index.ts
  registerMiniapp((session) => {
    new ConversateController(session).start();
  });
})();
